import { ArrowRight, ArrowUpRight } from 'lucide-react';
import IndustryGraphic from './IndustryGraphic';

export default function Hero() {
  return <section className="hero" id="inicio" aria-labelledby="hero-title">
    <div className="container hero-layout">
      <div className="hero-content">
        <span className="eyebrow"><span className="eyebrow-dot" /> INGENIERÍA · AUTOMATIZACIÓN · TRANSFORMACIÓN DIGITAL</span>
        <h1 id="hero-title">Conectamos ingeniería, procesos y <span>tecnología.</span></h1>
        <p>Diseñamos soluciones de automatización, integración industrial y transformación digital para construir operaciones más inteligentes y conectadas.</p>
        <div className="hero-actions">
          <a className="button button--primary" href="#servicios">Explorar soluciones <ArrowUpRight size={18} aria-hidden="true"/></a>
          <a className="button button--outline" href="#proyectos">Ver proyectos <ArrowRight size={18} aria-hidden="true"/></a>
        </div>
      </div>
      <IndustryGraphic />
    </div>
  </section>;
}
