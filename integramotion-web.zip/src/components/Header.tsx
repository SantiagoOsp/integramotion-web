import { useEffect, useState } from 'react';
import { ArrowUpRight, Menu, X } from 'lucide-react';
import Logo from './Logo';

const links = [
  { text: 'Inicio', url: '#inicio' },
  { text: 'Nosotros', url: '#nosotros' },
  { text: 'Servicios', url: '#servicios' },
  { text: 'Tecnologías', url: '#tecnologias' },
  { text: 'Proyectos', url: '#proyectos' },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (!open) return;
    const onEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', onEscape);
    return () => window.removeEventListener('keydown', onEscape);
  }, [open]);

  const closeMenu = () => setOpen(false);

  return (
    <header className={`site-header ${scrolled ? 'site-header--scrolled' : ''}`}>
      <div className="container header-inner">
        <a className="brand-link" href="#inicio" aria-label="IntegraMotion, ir al inicio" onClick={closeMenu}><Logo /></a>
        <nav className="desktop-nav" aria-label="Navegación principal">
          {links.map((link) => <a key={link.url} className={link.url === '#inicio' ? 'nav-link nav-link--home' : 'nav-link'} href={link.url}>{link.text}</a>)}
        </nav>
        <a className="button button--primary header-contact" href="#contacto">Contacto <ArrowUpRight size={16} aria-hidden="true" /></a>
        <button className="menu-toggle" type="button" aria-label={open ? 'Cerrar menú' : 'Abrir menú'} aria-controls="mobile-menu" aria-expanded={open} onClick={() => setOpen(v => !v)}>{open ? <X /> : <Menu />}</button>
      </div>
      {open && <nav id="mobile-menu" className="mobile-nav" aria-label="Navegación móvil">
        {[...links, {text:'Contacto', url:'#contacto'}].map(link => <a key={link.url} href={link.url} onClick={closeMenu}>{link.text}<ArrowUpRight size={16} aria-hidden="true" /></a>)}
      </nav>}
    </header>
  );
}
