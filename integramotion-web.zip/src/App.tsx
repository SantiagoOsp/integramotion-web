import Header from './components/Header';
import Hero from './components/Hero';
import Services from './components/Services';

export default function App() {
  return <>
    <a className="skip-link" href="#main">Saltar al contenido</a>
    <Header />
    <main id="main">
      <Hero />
      <Services />
      <section className="next-section" id="nosotros" aria-label="Presentación institucional"><div className="container next-panel"><h2>Ingeniería con visión integral.</h2><p>La presentación institucional detallada se incorporará en una próxima iteración.</p></div></section>
      <section className="next-section" id="tecnologias" aria-label="Tecnologías"><div className="container next-panel"><h2>Tecnologías industriales.</h2><p>Próximamente: arquitectura OT/IT, tecnologías y estándares aplicados.</p></div></section>
      <section className="next-section" id="proyectos" aria-label="Portafolio"><div className="container next-panel"><h2>Portafolio técnico.</h2><p>Próximamente: casos de estudio y proyectos documentados.</p></div></section>
      <section className="contact-section" id="contacto"><div className="container"><h2>Hablemos de ingeniería.</h2><p>La información y el formulario de contacto se habilitarán cuando estén definidos los canales oficiales de IntegraMotion.</p></div></section>
    </main>
    <footer className="footer"><div className="container"><span>© {new Date().getFullYear()} IntegraMotion</span><span>Sistemas conectados, industrias inteligentes.</span></div></footer>
  </>;
}
